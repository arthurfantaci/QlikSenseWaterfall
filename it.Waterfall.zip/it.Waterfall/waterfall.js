define([
        "jquery", 
        "text!./waterfall.css",
        "./d3.min"], 
        function($, cssContent) {
            'use strict';
	$("<style>").html(cssContent).appendTo("head");
	return {
		initialProperties : {
			version: 1.0,
			qHyperCubeDef : {
				qDimensions : [],
				qMeasures : [],
				qInitialDataFetch : [{
					qWidth : 2,
					qHeight : 1000
				}]
			}
		},
		definition : {
			type : "items",
			component : "accordion",
			items : {
				dimensions : {
					uses : "dimensions",
					min : 1,
					max: 1
				},
				measures : {
					uses : "measures",
					min : 1,
					max: 1
				},
				sorting : {
					uses : "sorting"
				},
				settings : {
					uses : "settings",
                                        items: {
                                          totalBar: {
                                                    type: "items",
                                                    label: "Total Bar",
                                                    items: {
                                                            totalBar: {
                                                                type: "string",
                                                                component : "switch",
                                                                label: "Total Bar",
                                                                ref: "qDef.totalBar",
                                                                options : [{
								value : true,
								label : "Show"
                                                                }, {
								value : false,
								label : "Hide"
                                                                }],
                                                                defaultValue : true,
                                                        },
                                                            totalBarLabel: {
                                                                ref: "qDef.totalBarLabel",
                                                                label: "Label",
                                                                type: "string",
                                                                expression: "optional",
                                                                defaultValue: "Total",
                                                                show : function(d) {
								return d.qDef.totalBar;
                                                            }
                                                        }
                                                        
                                                    }
                                            },
                                            dataPoint: {
                                                    type: "items",
                                                    label: "Values on datapoints",
                                            items: {
                                                valuesOnDataPoints: {
                                                    ref: "qDef.dataPoints",
                                                    label: "Values on datapoints",
                                                    component: "dropdown",
                                                    options: [ {
                                                                            value: "n",
                                                                            label: "No value"
                                                                        }, {
                                                                            value: "a",
                                                                            label: "Data Value"
                                                                        } ,
                                                                            {
                                                                            value: "c",
                                                                            label: "Cumulative"
                                                                        }],
                //						options: {"measure line","target line","background"},
                                                                type: "string",
                                                                defaultValue: "a"
                                                            }
                                                        }
                                                        },
                                        
                                            xAxis: {
                                                    type: "items",
                                                    label: "X-axis",
                                                    items: {
                                                            xAxisOrient: {
                                                                type: "string",
                                                                component: "radiobuttons",
                                                                label: "Text Orientation",
                                                                ref: "qDef.xOrient",
                                                                options: [ {
                                                                        value: "1",
                                                                        label: "-"
                                                                },{
                                                                        value: "2",
                                                                        label: "/"
                                                                },{
                                                                        value: "3",
                                                                        label: "|"
                                                                }
                                                            ],
                                                                defaultValue: "1"
                                                        },
                                                          xTextLen: {
                                                            ref: "qDef.xTextLen",
                                                            label: "Limit Label (Characters)",
                                                            type: "integer",
                                                            expression: "optional",
                                                            defaultValue: 20
                                                    }
                                                        
                                                        
                                                    }
                                            },
                                            yAxis: {
                                                    type: "items",
                                                    label: "Y-axis",
                                                    items: {
                                                          yNumTicks: {
                                                            ref: "qDef.yNumTicks",
                                                            label: "No. of Tickmarks",
                                                            type: "integer",
                                                            defaultValue: 5,
                                                            expression: "optional"
                                                        }                                                  
                                                        
                                                    }
                                            }/*,
                                            colors: {
                                                    type: "items",
                                                    label: "Colors",
                                                    items: {
                                                        colorType: {
                                                                type: "string",
                                                                component : "switch",
                                                                label: "Colors",
                                                                ref: "qDef.barColorType",
                                                                options : [{
								value : true,
								label : "Auto"
                                                                }, {
								value : false,
								label : "Custom"
                                                                }],
                                                                defaultValue : true,
                                                        },
                                                        colorDef: {
                                                            ref: "qDef.barColorDef",
                                                            label: "Bar color",
                                                            component: "dropdown",
                                                            options: [ {
                                                                        value: "f",
                                                                        label: "Fixed"
                                                                    }, {
                                                                        value: "e",
                                                                        label: "By Expression"
                                                                    } ],
                        //						options: {"measure line","target line","background"},
                                                                        type: "string",
                                                                        defaultValue: "f",
                                                                        show : function(d) {
                                                                               return (d.qDef.barColorType === true) ? false : true;}
                                                            },
                                                        colorExpression: {
                                                            ref: "qDef.colorExpression",
                                                            label: "Expression",
                                                            type: "string",
                                                            expression: "optional",
                                                            show: function(d) {
                                                                return (d.qDef.barColorDef === "e") ?true : false;
                                                            }                                                     
                                                            },
                                                        colorFixed: {
                                                            ref: "qDef.colorFixed",
                                                            label: "Color",
                                                            translation: "properties.color",
                                                            type: "string",
                                                            component: "color-picker",
                                                            defaultValue: 3,
                                                            show: function(d) {
                                                                return (d.qDef.barColorDef === "f" && d.qDef.barColorType === "a") ?true : false;
                                                            }
                                                        }
                                                        
                                                        
                                                        
                                                    }
                                            }*/
                                            
                                            }
				}
			}
		},
		snapshot : {
			canTakeSnapshot : true
		},
		paint : function($element,layout) {
			// get qMatrix data array
			var qMatrix = layout.qHyperCube.qDataPages[0].qMatrix;
			// create a new array that contains the measure labels
						
                        var xOrient = layout.qDef.xOrient;
                        var xLenght = layout.qDef.xTextLen;
                        var bottomMargin = (layout.qDef.xOrient === "1") ? 20 : 75;
                        var totalBar = layout.qDef.totalBar;
                        var totalBarLabel = layout.qDef.totalBarLabel;
                        var dataPointType = layout.qDef.dataPoints;
                        var yNumTicks = layout.qDef.yNumTicks;
                        
                       
                        
                        
                        // Creating Dataarray 
			var dataArr = qMatrix.map(function(d) {
				// for each element in the matrix, create a new object that has a property
				// for the grouping dimension, the first metric, and the second metric
			 	return {
			 		"label":d[0].qText,
			 		"value":d[1].qNum,
                                        "dataType":"qHyperCube",
                                    };
			});

                        
                        
                        
			// Chart object width
			var width = $element.width();
			// Chart object height
			var height = $element.height();
			// Chart object id
			var id = "container_" + layout.qInfo.qId;

			// Check to see if the chart element has already been created
			if (document.getElementById(id)) {
				// if it has been created, empty it's contents so we can redraw it
			 	$("#" + id).empty();
			}
			else {
				// if it hasn't been created, create it with the appropiate id and size
			 	$element.append($('<div />').attr("id", id).width(width).height(height));
			}

			render(dataArr,width,height,id,xOrient,bottomMargin,xLenght,totalBar,totalBarLabel,dataPointType,yNumTicks);                       		
		}
	};
});

var render = function (dataArr,w,h,id,xOrient,bottomMargin,xLenght,totalBar,totalBarLabel,dataPointType,yNumTicks) {
    
    var yScale = d3.scale.linear();
    var margin = {top: 20, right: 35, bottom: bottomMargin, left: 35},
        width = w - margin.left - margin.right,
        height = h - margin.top - margin.bottom;
    
    var data = [];
    
                /*
			var palette = [
                         '#b0afae',
                         '#7b7a78',
                         '#545352',
                         '#4477aa',
                         '#7db8da',
                         '#b6d7ea',
                         '#46c646',
                         '#f93f17',
                         '#ffcf02',
                         '#276e27',
                         '#ffffff',
                         '#000000'
			            ];*/
        
    calculateScale();
    
    var n = data.length;
    var xDelta = width / n;

    var svg = d3.select("#"+id).append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

	
    // X-axis
    var x = d3.scale.ordinal()
        .rangeRoundBands([0, width], 0.05)
        .domain(data.map(function (d) {
            return (xLenght === null) ? d.label : d.label.substring(0, xLenght);    
        }))
       ;
        
    var xAxis = d3.svg.axis()
        .scale(x)
        .orient("bottom");

    // Y-axis
    var y = d3.scale.linear()
        .range([height, 0]);

    var yAxis = d3.svg.axis()
        .scale(y)
        .ticks(yNumTicks)
        .orient("left");

    y.domain([this.minVal, this.maxVal]);
    yScale.domain([this.minVal, this.maxVal]).range([0, height]);
    calculateBars();
    addBarLabels();
    makeAxisLines();
     
    function numberWithCommas(x) {
        // Return the number formatted with commas
        return (x > 1000) ? x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : x.toString();
    }

    function calculateScale() {
        // Calculate scale of the y-axis for drawing waterfall bars
        var max = 0, min = 0, cumSum = 0;
        dataArr.forEach(function (d) {
            cumSum += d.value;
            if (cumSum < min) {
                min = cumSum;
            }
            if (cumSum > max) {
                max = cumSum;
            }
 //           var barClass = function (d) {return (d.value < 0) ? "negative" : "positive"; }});
            data.push({value: d.value, cumulativeSum: cumSum, label: d.label, entryType: "data"});
        });
        
        if (totalBar === true) {
          data.push({
                label: totalBarLabel,
                cumulativeSum: cumSum,
                value: cumSum,
                entryType: "total"
            });
        }
        this.maxVal = max*1.05;
        this.minVal = min;
    }  
  

    function calculateBars() {
        // Calculate and add rectangles to the chart
        svg.selectAll("rect")     
            .data(data)
            .enter()
            .append("rect")
            .attr("class", 
                //function (d) {return (d.value < 0) ? "negative" : "positive"; })
             function (d) {return d.entryType === "total" ? "total" : (d.value < 0) ? "negative" : "positive"; })
            .attr("x", function (d, i) {
                return i * xDelta+5;
            })
            .attr("y", function (d, i) {
                return (d.value < 0) ? height - yScale(d.cumulativeSum - d.value) : height - yScale(d.cumulativeSum);
            })
            .attr("width", function (d) {
                return xDelta-3; /*Make space between bars*/
            })
            .attr("height", function (d) {
                return yScale(Math.abs(d.value));
            })
            //.attr("fill", 'rgb(255, 0, 0)');
                   
    }

    function addBarLabels() {
        // Add labels to the rectangles
        var barLabels = svg.append("g")
            .selectAll('text')
            .data(data)
            .enter()
            .append("text")
            .attr("x", function (d, i) {
                return i * xDelta + xDelta * .2 + margin.left / 2;
            })
            .attr("y", function (d, i) {
                return (d.value < 0) ? height - yScale(d.cumulativeSum) + 25 : height - yScale(d.cumulativeSum);
            })
            .attr('dy', -5)
            .text(function (d) {
                //return numberWithCommas(d.value.toFixed(0));
                return (dataPointType === "n") ? "" : (dataPointType === "a") ? numberWithCommas(d.value.toFixed(0)) :numberWithCommas(d.cumulativeSum.toFixed(0));
            });
    }

    function makeAxisLines() {
        if(xOrient === "1") {
        // Draw x- and y- axis lines 0 degrees
            svg.append("g")
            .attr("class", "axis")
            .attr("transform", "translate(0," + height + ")")
            .call(xAxis);
           }  else  if(xOrient === "2") {
        // Draw x- and y- axis lines 65 degrees
            svg.append("g")
            .attr("class", "axis")
            .attr("transform", "translate(0," + height + ")")
            .call(xAxis)
           .selectAll("text")  
            .style("text-anchor", "end")
            .attr("dx", "-.8em")
            .attr("dy", ".20em")
            .attr("transform", function(d) {
                return "rotate(-65)" 
                });
            }  else  if(xOrient === "3") {
        // Draw x- and y- axis lines 65 degrees
            svg.append("g")
            .attr("class", "axis")
            .attr("transform", "translate(0," + height + ")")
            .call(xAxis)
           .selectAll("text")  
            .style("text-anchor", "end")
            .attr("dx", "-.8em")
            .attr("dy", "-.40em")
            .attr("transform", function(d) {
                return "rotate(-90)" 
                });
            } 
  
        svg.append("g")
            .attr("class", "axis")
            .call(yAxis);

    }

};